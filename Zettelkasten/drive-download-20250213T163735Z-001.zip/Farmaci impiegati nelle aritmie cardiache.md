2025-01-28 22:58
Stato: #ideaibro 
Tag: #Farmacologia #ApparatoCardiocircolatorio 

---
>[!info]
>Le **aritmie cardiache** rappresentano un problema ricorrente nella pratica clinica e si riscontrano nel 25% dei pazienti trattati con [[Glicosidi digitalici|digitale]], nel 50% di quelli sottoposti ad ==anestesia locale== ed in oltre l'80% dei soggetti con [[Infarto miocardico|infarto miocardico acuto]].
- Viene richiesto spesso un trattamento: contrazioni troppo rapide, troppo lente o asincrone possono ridurre considerevolmente la gittata cardiaca
	- alcune portano ad alterazioni del ritmo più gravi o letali
	- i farmaci antiaritmici
		- possono salvare la vita
		- possono *precipitare* la condizione, causando aritmie letali[^1]
- Trattamento
	- farmaci antiaritmici
	- terapie non farmacologiche:
		- *pacemaker*[^2]
		- cardioversione
		- ablazione del focolaio aritmico tramite catetere
		- trattamento chirurgico
## Elettrofisiologia del ritmo cardiaco normale
>[!info]- Normale attività elettrica cardiaca
>![Rappresentazione schematica del cuore e della normale attività elettrica cardiaca (registrazioni intracellulari delle aree indicate da ECG).](https://i.imgur.com/TGZZIfn.jpeg)
1. L'impulso elettrico che induce una normale contrazione cardiaca si origina, ad intervalli regolari, nel nodo senoatriale (SA)
	- generalmente con una ==f = 60-100 battiti/min==
2. L'impulso si propaga rapidamente attraverso gli atri e penetra nel nodo atrioventricolare (AV)
	- in condizioni normali, è l'unica via di conduzione tra atri e ventricoli
	- la conduzione è lenta e richiede ca. 0,15s (tale ritardo dà tempo alla contrazione atriale di spingere il sangue nei ventricoli)
3. L'impulso si propaga nel sistema id His-Purkinje e raggiunge tutte le parti dei ventricoli
	- a partire dalla superficie endocardica vicino all'apice e terminando sulla superficie epicardica alla base del cuore
	- t$_{\text{attivazione ventricolare}}$ < 0,1s → ==contrazione ventricolare sincrona ed emodinamicamente efficiente==
- Le **aritmie** consistono in **depolarizzazioni cardiache che si discostano dalla descrizione fatta sopra per uno o più aspetti**: vi è un'anormalità nel sito di origine dell'impulso, nella sua frequenza, nella sua regolarità o nella sua condizione
### Basi ioniche dell'attività elettrica di membrana
![Rappresentazione schematica delle modifiche di permeabilità ionica e dei processi di trasporto che si verificano durante un potenziale d'azione ed il periodo diastolico che lo segue.](https://i.imgur.com/7eDXlqH.png)
#### Concentrazioni e canali ionici
- Il ==potenziale di membrana delle cellula cardiaca== è determinato da *concentrazioni di diversi ioni[^3] sui due lati della membrana* e dalla *permeabilità stessa a ciascuno ione*
	- gli ioni, essendo idrosolubili, non sono in grado di diffondere liberamente attraverso le membrane cellulari, seguendo i gradienti di concentrazione ed elettrico
	- vi è la necessità di ==canali acquosi==
	- il movimento ionico genera le correnti che costituiscono la base del potenziale d'azione cardiaco
- I singoli canali sono relativamente specifici per uno ione e il flusso è controllato da "cancelli"
	- ogni tipo di canale ha il suo cancello
	- i canali Na$+$, Ca$^{2+}$ e K$^+$ sono aperti e chiusi dalle variazioni del voltaggio (*sensibili al voltaggio*)
	- la maggior parte dei canali è anche regolata da condizioni ioniche e metaboliche
		- alcuni del K$^+$ sono principalmente controllati da ligandi
- In aggiunta ai canali ionici, ==la cellula dev'essere provvista di meccanismi adeguati a mantenere stabili le condizioni ioniche tra le due parti della membrana==
	- pompa del sodio Na$^+$/K$^+$-ATPasi
		- più importante dei meccanismi attivi
		- come altre pompe, mantenendo i gradienti necessari per la diffusione attraverso canali, *contribuisce indirettamente al mantenimento del potenziale di membrana*
	- alcune pompe e scambiatori producono un *flusso ionico netto*, per cui sono detti "elettrogeni"
#### Controllo del voltaggio
##### Legge di Ohm
- Quando la membrana delle cellule cardiache diventa permeabile ad uno specifico ione[^4], il movimento di esso attraverso la membrana è dato da $$Corrente = \frac{Voltaggio}{Resistenza}\text{ V  } Corrente = \text{Voltaggio x Conduttanza}$$
	- *conduttanza*: determinata dalle proprietà della proteina costitutiva di ciascun canale ionico
	- *voltaggio*: differenza fra potenziale di membrana effettivo e potenziale di inversione per quello ione[^5]
###### Per il sodio
- In una cellula cardiaca a riposo, tende ad essere riportato all'interno delle cellule per
	- marcato gradiente di concentrazione:
		- 140 mmol/L Na$^+$ all'esterno
		- 10-15 mmol/L Na$^+$ all'interno
	- gradiente elettrico:
		- 0 mV all'esterno
		- -90 mV all'interno
- Differenze di flusso:
	- a riposo i suoi canali sono chiusi → **no flusso**
	- apertura → abbondante flusso verso l'interno → **fase 0 di depolarizzazione**
###### Per il potassio
- Il ==gradiente diretto verso l'interno== è in ==equilibrio== con ==quello diretto all'esterno==
	- gradiente di concentrazione (140 mmol/L; 4 mmol/L all'esterno) → spinta all'esterno
	- gradiente elettrico → spinta all'interno
- Alcuni canali per il potassio (detti canali "*rettificanti in entrata*") sono aperti nella cellula a riposo, ma il flusso di corrente attraverso di essi è basso per via dell'equilibrio
##### Equazione di Nernst
- L'equilibrio (o **potenziale di inversione**) per gli ioni è dato da $$E_{ion} = 61 \text{ x } log(C_e/C_i)$$
	- $C_e$ e $C_i$ sono, rispettivamente, le concentrazioni extracellulari ed intracellulari moltiplicate per i loro coefficienti di attività
###### Nella cellula a riposo
- Da notare che l'aumento del potassio extracellulare rende l'E$_k$ meno negativo
	- quando questo si verifica, la membrana si depolarizza finché non viene raggiunto il nuovo E$_k$
- Principali fattori che determinano il potenziale di membrana:
	- ==concentrazione extracellulare di potassio==
	- ==attività dei canali rettificanti in entrata==
###### Nella maggior parte delle cellule non pacemaker
- Ci si avvicina alle condizioni di applicazione dell'equazione di Nernst in corrispondenza di
	- *picco dei valori positivi* per il potenziale di membrana (concentrazioni di $Na^+$)
	- *fase di riposo* (concentrazioni di $K^+$)
##### Equazione di Goldman-Hodgkin-Katz
- Se la permeabilità è significativa sia per $Na^+$ che per $K^+$, l'equazione di Nernst non è adatta per predire correttamente il potenziale di membrana; dunque $$E_{mem} = 61\text{ }*\text{ }log\frac{P_K\text{ }*\text{ }K_e\text{ + }P_{Na}\text{ }*\text{ }Na_e}{P_K\text{ }*\text{ }K_i\text{ + }P_{Na}\text{ }*\text{ }Na_i}$$
#### Potenziale pacemaker
- Nelle cellule *pacemaker* (sia normali che ectopiche), una **depolarizzazione spontanea** si verifica durante la diastole
	- risulta da un graduale aumento della corrente di depolarizzazione, attraverso speciali canali ionici attivati dall'iperpolarizzazione (I$_f$, chiamati anche I$_h$)
- L'effetto sulla ==permeabilità al potassio== è più importante in una cellula *pacemaker*
	- aumento del $K^+$ extracellulare → rallentamento o arresto dell'attività pacemaker
	- ipopotassiemia → insorgenza di pacemaker ectopici
##### Appendice: effetti del potassio
- Gli effetti di ==modifiche del potassio sierico== possono sembrare ==paradossali== se ci si basa esclusivamente su una considerazione delle modifiche nel *gradiente elettrochimico* del potassio
- A livello cardiaco, tuttavia, ==modificano ulteriormente la conduttanza==
	- indipendentemente da semplici modifiche della forza elettrochimica vettrice
	- es. ↑↑ $K^+_{extracellulare}$ → ↑↑ conduttanza al $K^+$
>[!warning]
> La frequenza del pacemaker e aritmie coinvolgenti cellule pacemaker ectopiche sembrano più sensibili a modifiche delle concentrazioni di potassio sierico rispetto a cellule del nodo SA.
>- Ciò, probabilmente, contribuisce all'aumentata sensibilità agli agenti antiaritmici bloccanti i canali del $K^+$ (==chinidina== e ==sotalolo==) durante l'ipopotassiemia (es. prolungamento accentuato del potenziale d'azione e tendenza a causare torsioni di punta).
###### Iperpotassiemia
>Vedi [[iperkaliemia#ECG|ECG nell'iperkaliemia]]
1. Riduzione della durata del potenziale d'azione
2. diminuzione della frequenza del pacemaker
3. diminuita aritmogenesi da pacemaker
###### Ipopotassiemia
>Vedi [[Ipokaliemia#A livello dell'ECG|ECG nell'ipokaliemia]]
4. Prolungamento della durata del potenziale d'azione
5. Aumentata frequenza del pacemaker
6. Aumentata aritmogenesi da pacemaker
### La membrana cellulare attiva
#### Fase 0
- Nelle cellule normali dell'atrio, del sistema del Purkinje e del ventricolo la fase ascendente del potenziale d'azione dipende dalla corrente del Na$^+$
##### Canali del Na$^+$
>I tre stati del **canale del Na$^+$** rappresentano tre diverse conformazioni della proteina stessa
>	- si stanno attualmente identificando le regioni della proteina che conferiscono specifiche proprietà al canale (sensibilità al voltaggio, capacità di formare il poro, inattivazione del canale)
>	- ![Rappresentazione schematica dei passaggi del canale del Na$^+$ attraverso i diversi stati conformazionali durante il potenziale d'azione cardiaco.](https://i.imgur.com/JffcsXn.png)
>1. La depolarizzazione fino al raggiungimento del voltaggio soglia causa l'apertura dei cancelli di attivazione (*m*) dei canali del Na$^+$
>	- se i cancelli di inattivazione (*h*) non sono stati ancora chiusi, i canali sono aperti o inattivati e ne consegue un considerevole aumento della permeabilità al Na$^+$
>2. Il ==sodio extracellulare diffonde verso l'interno della cellula== secondo il suo gradiente elettrochimico e ==il potenziale di membrana si avvicina rapidamente al potenziale di equilibrio per il sodio==
>	- (E$_{Na}$ = ca. +70 mV quando Na$_c$ = 140 mmol/L e Na$_i$ = 10 mmol/L)
>3. Quest'intensità di corrente è di durata molto breve: l'apertura dei cancelli *m* in risposta alla depolarizzazione è seguita prontamente dalla chiusura dei cancelli *h* e inattivata dai canali del Na$^+$
##### Canali del Ca$^{2+}$
>La maggior parte dei **canali del Ca$^{2+}$** viene attivata e inattivata in maniera apparentemente simile a quelli del sodio, ma, in quelli Ca$_L$[^6], ==le variazioni==
>- ==si hanno a potenziali più positivi==;
>- ==avvengono più lentamente==.
#### Fase 1 e 2
- Si ha un *plateau* riflettente
	- l'arresto della maggior parte della corrente del sodio
	- l'attivazione e il declino della corrente del calcio
	- il lento sviluppo di una corrente ripolarizzante del potassio
#### Fase 3
- Durante la **ripolarizzazione**, il potenziale d'azione si avvicina sempre di più a quello di equilibrio del potassio mediante
	- aumento della permeabilità al K$^+$
	- inattivazione dei canali del Na$^+$ e del Ca$^{2+}$
- Le principali correnti del potassio sono due[^7]:
	1. I$_{Kr}$ → corrente di Crotone? No, corrente che si attiva rapidamente
	2. I$_{Ks}$ → corrente che si attiva lentamente
	- un'==altra corrente distinta== può controllare la ==ripolarizzazione nelle cellule del nodo SA==
		- di fatto, farmaci prolunganti la ripolarizzazione nelle cellule di Purkinje e in quelle ventricolari presentano scarso effetto sulla ripolarizzazione del nodo SA
### Effetto del potenziale di riposo sul potenziale d'azione
- I *cancelli h* dei canali del Na$^+$ in una membrana riposo ==si chiudono a valori di potenziale compresi tra -75 e -55 mV==
	- un minor numero di canali è "disponibile" per la diffusione di ioni Na$^+$ quando il potenziale d'azione si genera da un potenziale di riposo di -60 mV piuttosto che quando ha origine da un potenziale di riposo di -80 mV
	- durante il *plateau*, la maggior parte dei canali del Na$^+$ è in stato inattivo
		- ripolarizzazione → recupero dello stato attivo → canali nuovamente disponibili all'eccitaz.
- ![Dipendenza della funzione di canali per il Na$^+$ dal potenziale di membrana che precede lo stimolo.](https://i.imgur.com/tugFMkP.png)
#### Conseguenze della riduzione del picco della permeabilità al Na$^+$
1. Ridotta velocità di ascesa del potenziale (V$_{max}$ = velocità con cui varia il voltaggio della membrana)
2. Ridotta ampiezza del potenziale d'azione
3. Ridotta eccitabilità e ridotta velocità di conduzione
#### Refrattarietà
>[!info]
>**Periodo refrattario**: tempo intercorrente fra fase 0 e un ripristino dei canali per il Na$^+$ in fase 3 sufficiente a consentire il propagarsi di una risposta ad uno stimolo esterno.
- Modifiche nella refrattarietà[^8]
	- possono essere importanti nella genesi o nella soppressione di alcune aritmie
	- implicano un prolungamento del tempo di recupero
##### Stimolo depolarizzante breve e improvviso
>Sia esso causato dalla propagazione di un potenziale d'azione o da elettrodi esterni
- Provoca l'apertura di un numero di cancelli di attivazione prima che si possa chiudere un numero significativo di cancelli di inattivazione
##### Lenta riduzione (depolarizzazione) del potenziale di riposo
>Sia essa dovuta ad iperpotassiemia, blocco della pompa del Na$^+$ o danno ischemico delle cellule
- Porta ad una diminuzione delle correnti del Na$^+$ durante l'ascesa del potenziale d'azione
#### Risposte "lente"
>Depolarizzazione a -55 mV = abolizione delle correnti del Na$^+$
- Si è visto che cellule a -55 mV possono generare ==particolari potenziali d'azione== in circostanze in cui è *aumentata la permeabilità al calcio* o *diminuita la permeabilità al potassio*
- Si dicono tali per la ==bassa velocità di ascesa== e la ==lenta conduzione==
- Dipendono dalla corrente del Ca$^{2+}$ in entrata e costituiscono la normale attività elettrica nei nodi SA e AV
	- questi tessuti hanno valori di potenziale di riposo normalmente compresi tra -50 e -70 mV
## Appendice: basi molecolari e genetiche delle aritmie cardiache
>[!info]- Tabella
>![Aritmie cardiache, basi genetiche e molecolari di alcune di esse (tabella).](https://i.imgur.com/SFe2mk8.png)
### Torsione di punta e sindromi del QT lungo
#### Patologia
- **Tachicardia ventricolare polimorfica** associata a
	- prolungamento del tratto QT (soprattutto all'inizio)
	- sincope
	- morte improvvisa
- L'effetto può essere attribuito ad un aumentata corrente d'ingresso (perdita d'azione) o ad un'aumentata corrente di uscita (perdita di funzione) durante il *plateau* del potenziale d'azione
#### Geni interessati
- Sono state identificate fino a 300 [[Mutazioni e sistemi di riparazione del DNA#Mutazioni|mutazioni]] diverse in almeno 8 geni di canali ionici determinanti la sindrome congenita del QT lungo (LQT), ciascuna con diverse implicazioni cliniche:
	- mutazioni con perdita di funzione nei geni di canali per il K$^+$
		- portano a riduzione della corrente di uscita ripolarizzante
		- responsabili dei sottotipi 1, 2, 5, 6 e 7 del LQT
	- i geni *HERG* e *KCNE2* (*MiRP1*) codificano per subunità della I$_{Kr}$
	- *KCNQ1* e *KCNE1* (*minK*) codificano per subunità della I$_{Ks}$
	- *KCNJ2* codifica per una corrente del potassio rettificatrice di ingresso (I$_{Kir}$)
	- mutazioni nel gene del canale del Na$^+$ (*SCN5A*) o del gene del canale del Ca$^{2+}$ (*CACNA1c*) con aumento di funzione aumentano la corrente di ingresso al *plateau* e sono responsabili rispettivamente dei sottotipi 3 e 8 del LQT
#### Nuovi approcci terapeutici
- Similitudine fra casi congeniti e acquisiti: il canale del potassio I$_{Kr}$ è bloccato o modificato da vari farmaci (es. ==chinidina==, ==sotalolo==) o anomalie elettrolitiche (ipopotassiemia, [[ipomagnesemia]], [[ipocalcemia]]) che producono torsioni di punta
- Esempio di approccio molecolare specifico: la ==mexiletina== (bloccante del canale del Na$^+$) può correggere le manifestazioni cliniche della sindrome congenita del LQT sottotipo 3
- Probabilmente, la torsione di punta origina da ascese del potenziale d'azione derivanti da post-depolarizzazioni precoci; quindi la terapia è rivolta a correggere l'ipopotassiemia
	- eliminando depolarizzazioni indotte (es. usando [[Farmaci antagonisti sui recettori adrenergici#Farmacologia di base degli antagonisti sui recettori $ beta$-adrenergici|β-bloccanti]] o Mg$^{2+}$)
	- abbreviando il potenziale d'azione (es. aumentando la frequenza cardiaca con ==isoprenalina== o stimolazione elettrica)
### Sindromi del QT corto
- Ne sono state riconosciute tre legate a mutazioni con aumento di funzione in tre diversi geni del canale del K$^+$ (*KCNH2*, *KCNQ1* e *KCNJ2*)
### Tachicardia ventricolare catecolaminergica polimorfa
- Caratterizzata da sincope indotta da stress o emozioni
- Può essere determinata da mutazioni genetiche in due proteine differenti del reticolo sarcoplasmatico controllanti l'omeostasi intracellulare di Ca$^{2+}$
### Sindrome del seno malato
- Collegata a mutazioni in due differenti geni di canali ionici (*HCN4* e *SCN5A*)
### Sindrome di Brugada
- Caratterizzata da fibrillazione ventricolare associata a persistente sovralivellamento del segmento ST
- Ricollegata a mutazione con perdita di funzione nel gene del canale del Na$^+$ *SCN5A*
### Disordine progressivo della conduzione cardiaca (PCCD)
- Caratterizzato da
	- alterata conduzione nel sistema di His-Purkinje
	- blocco di branca dx o sx esitante in blocco atrioventricolare completo
- Anch'essa dovuta a mutazione di *SCN5A*, ma una differente dalla sindrome di Brugada
### Fibrillazione atriale familiare
- Almeno una forma è causata da una mutazione con aumento di funzione nel gene del canale del K$^+$ *KCNQ1*
## Meccanismi delle aritmie
- Molti fattori possono scatenare o esacerbare un'aritmia:
	- ischemia
	- ipossia
	- acidosi o alcalosi
	- disturbi elettrolitici
	- esposizione eccessiva alle catecolamine
	- influenze da parte del SN autonomo
	- tossicità di farmaci (es. [[Glicosidi digitalici|digitale]] o antiaritmici)
	- eccessiva distensione delle fibre cardiache
	- presenza di tessuto cicatriziale o, altrimenti, malato
- Tutte le aritmie derivano da
	1. alterazioni della formazione dell'impulso
	2. alterazioni della conduzione dell'impulso
	3. entrambe
### Alterazioni della generazione dell'impulso
#### Pendenza nella fase 4
- L'intervallo tra due depolarizzazioni successive di una cellula pacemaker è dato dalla ==somma== della ==durata del potenziale d'azione== e di ==quella dell'intervallo sistolico==
	- l'accorciamento di uno di questi periodi porta ad **aumento della frequenza del pacemaker**
	- l'intervallo diastolico (più importante dei due) è determinato soprattutto dalla pendenza della ==fase 4 di depolarizzazione== (potenziale *pacemaker*):
		- *rallentamento* della normale frequenza = riduzione della pendenza della fase 4
			- scarica vagale
			- farmaci β-bloccanti
		- *accelerazione* della normale frequenza = aumento della pendenza della fase 4
			- ipokaliemia
			- stimolazione dei recettori β-adrenergici
			- farmaci cronotropi positivi
			- distensione delle fibre
			- acidosi
			- depolarizzazione parziale dovuta a correnti di lesione
- Pacemaker latenti[^9] sono particolarmente inclini ad essere stimolati dai meccanismi enunciati
	- tutte le cellule cardiache, tuttavia, possono mostrare attività di *pacemaker* ripetitiva, se depolarizzate in condizioni appropriate
#### Post-depolarizzazioni
- Depolarizzazioni transitorie che interrompono
	- fase 3 → **post-depolarizzazioni precoci** o **EAD** (*Early After Depolarizations*)
		- esacerbate da basse frequenze cardiache
		- si ritiene che contribuiscano allo sviluppo di aritmie legate a lunghi intervalli QT
	- fase 4 → **post-depolarizzazioni ritardate** o **DAD** (*Delayed After Depolarizations*)
		- esacerbate da elevate frequenze cardiache
		- ritenute responsabili di alcune aritmie legate a
			- sovraccarico di digitale
			- catecolamine
			- ischemia del miocardio
- ![Aritmie, post-depolarizzazioni precoci e tardive.](https://i.imgur.com/ZwbvBOZ.png)
### Alterazioni nella conduzione dell'impulso
#### Blocco
- Può essere dovuto a **condizione dell'impulso fortemente depressa**
	- es. AV o blocco di branca
- Essendo il controllo parasimpatico significativo, il blocco AV parziale viene, a volte, risolto, dall'==atropina==
#### Rientro
>Conosciuto anche come "movimento circolare"
- Alterazione frequente della conduzione, in cui **un impulso torna indietro** ed **eccita alcune aree del miocardio più di una volta**
- La via può
	- essere confinata a zone molto piccole (es. entro o vicino al nodo AV)
	- interessare zone estese delle pareti atriali o ventricolari
- L'impulso circolante spesso genera "==impulsi figli=="
	- possono diffondersi al resto del cuore
	- in rapporto al numero dei giri del circuito che l'impulso fa prima di estinguersi, l'aritmia si può manifestare
		- con una o più extrasistoli
		- tachicardia sostenuta
##### Differenze d'impulso
- Alcune forme sono strettamente determinate da ==fattori anatomici==
	- es. nella [[Aritmie#Sindrome di Wolf-Parkinson-White|sindrome di Wolf-Parkinson-White]], il circuito di rientro è formato da
		- tessuto atriale
		- nodo AV
		- tessuto ventricolare
		- connessione AV accessoria (*fascio di Kent*, un "tratto bypass")
- In altri casi, nel miocardio possono ==venirsi a creare== continuamente ==vari circuiti multipli di rientro==
	- es. fibrillazione atriale o ventricolare
##### Condizioni di esistenza
>[!info]
>![Aritmie, schema di un circuito di rientro che può verificarsi in piccole branche del sistema di Purkinje che si biforcano dove esse entrano nella parete ventricolare.](https://i.imgur.com/AUk96Va.png)
1. Dev'essere presente un **ostacolo** (anatomico o fisiologico) **alla conduzione uniforme**, tale da stabilire un circuito lungo il quale l'onda di rientro possa propagarsi
2. Il **blocco**, in qualche punto del circuito, dev'essere **unidirezionale**: la conduzione deve
	1. estinguersi in una direzione
	2. continuare in quella opposta
	- tale processo è detto *conduzione decrementale*
3. Il tempo di conduzione nel circuito dev'essere abbastanza lungo da impedire all'impulso retrogrado di entrare in tessuti refrattari quando si propaga attorno all'ostacolo
	- **t$_{conduzione}$ > periodo refrattario**
##### Cause
>[!warning]- Va sottolineato che
>Il rientro dipende da una **depressione della conduzione fino a un livello critico**, di solito come risultato di un danneggiamento o un'ischemia.
- Un rallentamento della conduzione può essere dovuto a
	- depressione della corrente del Na$^+$
	- depressione della corrente del Ca$^{2+}$
	- entrambe
###### Condizioni differenti
- Velocità di conduzione troppo bassa → *blocco bidirezionale*
	- se l'impulso che rientra è troppo debole
		- la conduzione può venir meno
		- l'impulso può arrivare così tardi da collidere col successivo impulso regolare
- Velocità di conduzione troppo rapida → *conduzione bidirezionale*
- Anche in presenza di un blocco unidirezionale, se l'impulso diffonde intorno all'ostacolo troppo rapidamente, raggiungerà un *tessuto ancora refrattario*
##### Intervento farmacologico
- Farmaci che aboliscono il rientro agiscono
	- ==deprimendo ulteriormente la conduzione== (blocco della corrente del Na$^+$ o del Ca$^{2+}$)
	- ==causando blocco bidirezionale==
###### Ulteriori meccanismi
- ==Accelerazione della conduzione== sarebbe efficace, ma solo in circostanze inconsuete questo meccanismo può spiegare l'azione farmacologica
- ==Aumento== o la ==diminuzione== del ==periodo refrattario== possono ridurre le probabilità di un rientro:
	- maggiore è la durata nel tessuto vicino al blocco, più è alta la probabilità che il tessuto sia ancora refrattario quando vi è il tentativo di rientro
	- più è corto il periodo refrattario, minori sono le probabilità che si verifichi un blocco unidirezionale
#### ECG a confronto
![Aritmie, ECG di normale ritmo sinusale e di alcune aritmie comuni.](https://i.imgur.com/aOb1mgZ.png)
![Aritmie, ECG di tachicardia ventricolare polimorfa (torsione di punta).](https://i.imgur.com/fL0Quve.png)
![Aritmie, ECG di tachicardia ventricolare polimorfa (torsione di punta) - commento.](https://i.imgur.com/N1hdQ4i.png)
# Basi farmacologiche dell'azione dei farmaci impiegati nelle aritmie
### Meccanismi d'azione
- Lo scopo della terapia è quello di
	- ==ridurre l'attività dei *pacemaker* ectopici==
	- ==modificare la conduzione o refrattarietà in circuiti di rientro per disattivare propagazioni circolari dell'impulso==
#### Vie di espletazione
- I meccanismi principali sono
	1. blocco del canale del Na$^+$
	2. blocco degli effetti del sistema simpatico sul cuore
	3. prolungamento del periodo refrattario effettivo
	4. blocco dei canali del Ca$^{2+}$
- Inoltre
	- riduzione automatismo dei pacemaker ectopici >> riduzione automatismo del nodo SA
	- riduzione della conduzione e dell'eccitabilità
	- aumento periodo refrattario nel tessuto depolarizzato >> tessuto normale depolarizzato
#### Meccanismo "uso-dipendente" o "stato-dipendente"
>[!info]
>I canali molto sfruttati (o in uno stato di inattivazione) sono molto più sensibili al tocco.
- I farmaci agenti sui canali si ==legano rapidamente== ai canali attivati (fase 0) o inattivati (fase 2), mentre si ==legano poco o per niente== ai canali a riposo
- Si ha **blocco** dell'attività elettrica quando si ha
	- *elevata tachicardia* (tante attivazioni e inattivazioni per unità di tempo)
	- *riduzione significativa del potenziale di riposo* (molti canali inattivati a riposo)
##### Differenze intercellulari
![Aritmie, blocco stato- e frequenza- dipendente dei canali del Na$^+$ da parte di farmaci antiaritmici.](https://i.imgur.com/IAeHZTe.png)
###### Cellule normali
- I canali bloccati durante il normale ciclo di attivazione-inattivazione perderanno rapidamente il farmaco dai recettori nel periodo di riposo del ciclo
###### Cellule cronicamente depolarizzate
>Potenziale di riposo > -75 mV
- I canali si riprenderanno dal blocco molto lentamente o non si riprenderanno affatto
- ==Riduzione della pendenza nella fase 4==
	- generalmente
		1. blocco dei canali di Na$^+$ e Ca$^{2+}$ →  riduzione della permeabilità a Na$^+$, Ca$^{2+}$ e K$^+$
		2. stabilizzazione del potenziale più vicino a quello di riposo del potassio
	- alcuni possono anche aumentare la soglia (rendendola più positiva)
	- i $\beta$-bloccanti la riducono indirettamente (blocco dell'azione cronotropa positiva della NE)
#### Nelle aritmie da rientro
1. ==Riduzione stabile del numero dei canali disponibili non bloccati== → riduzione delle correnti eccitatorie
2. ==Prolungamento del tempo di recupero dei canali ancora in grado di raggiungere lo stato di riposo==, per cui extrasistoli precoci sono del tutto incapaci di propagarsi
	- gl'impulsi successivi si propagano più lentamente e sono sottoposti a blocco bidirezionale
#### Benefici ed effetti indesiderati
##### Vantaggi
- Scarsissima interferenza con le parti del cuore normalmente depolarizzate
- Vengono soppressi
	- automatismo ectopico
	- anomalie di conduzione in cellule depolarizzate
##### Svantaggi
- Aumento della dose → capacità di depressione in tessuti normali → **aritmie *indotte da farmaci***
- Una concentrazione di farmaco terapeutica (antiaritmica) nelle condizioni esistenti all'inizio del trattamento può diventare aritmogena (proaritmica) in presenza di
	- frequenze cardiache elevate → maggior sviluppo di blocco
	- acidosi → recupero dal blocco farmacologico più lento
	- iperkaliemia
	- ischemia
# Farmaci antiaritmici specifici
>Lo schema di classificazione individua 4 classi:
>1. **==blocco dei canali del sodio==**
>	- 1A: prolungamento dell'APD[^10]
>	- 1B: abbreviazione dell'APD in alcuni tessuti cardiaci + dissociazione dal canale con cinetica rapida
>	- 1C: effetti minimi sull'APD + dissociazione dal canale con cinetica lenta
>2. **==azione simpaticolitica==**
>	- riduzione dell'attività $\beta$-adrenergica
>3. **==prolungamento dell'APD==**
>	- blocco della I$_{Kr}$
>4. **==blocco della corrente del calcio==**
>	- rallentamento della conduzione in regioni in cui l'ascesa del potenziale è Ca$^{2+}$-dipendente (es. nodi SA e AV)
>Un farmaco può anche avere azioni proprie di più di una classe

>[!info]- Azioni di membrana (tabella)
>![Farmaci antiaritmici, azioni di membrana (tabella).](https://i.imgur.com/xk3JHVY.png)

>[!info]- Proprietà clinico-farmacologiche (tabella)
>![Farmaci antiaritmici, proprietà clinico-farmacologiche (tabella).](https://i.imgur.com/GnbMaZ5.png)
## Farmaci bloccanti i canali del $Na^+$ (classe I)
- Si tratta di ==farmaci con azione anestetica locale== → blocco canali del Na$^+$ e riduzione corrente I$_{Na}$
- Gruppo più vecchio di farmaci antiaritmici, ancora largamente utilizzati
### Procainamide (sottogruppo 1A)
![Procainamide.](https://i.imgur.com/qZYsRea.png)
#### Effetti cardiaci
- Bloccando i canali del sodio, l'azione consiste in
	- rallentamento della fase ascendente del potenziale d'azione
	- rallentamento della conduzione
	- prolungamento della durata del complesso QRS dell'ECG
	- prolungamento dell'APD[^11] per blocco non specifico dei canali del K$^+$
- Rispetto alla ==chinidina==:
	- meno efficace nel sopprimere l'attività di *pacemaker* ectopici abnormi
	- più efficace nel bloccare i canali del Na$^+$ nelle cellule depolarizzate
- ==Deprime direttamente i nodi SA e AV==
	- azioni controbilanciate solo in piccola parte dall'azione vagolitica
#### Effetti extracardiaci
- ==Attività ganglioplegica==
	- riduce le resistenze vascolari e può provocare ipotensione (specialmente IV)
	- a concentrazioni terapeutiche, i suoi effetti vascolari periferici sono meno evidenti di quelli indotti dalla chinidina
- Si osserva **ipotensione** solo
	- durante infusione eccessivamente rapida
	- in presenza di preesistenti serie disfunzioni del ventricolo sx
#### Tossicità
- Gli effetti cardiotossici comprendono
	- *eccessivo prolungamento del potenziale d'azione*
	- *prolungamento dell'intervallo QT*
	- induzione di **torsioni di punta** e **sincope**
	- (possono essere indotte nuove aritmie)
- Un effetto collaterale preoccupante associato alle terapie a lungo termine è una **sindrome molto simile al [[Lupus eritematoso sistemico (LES)|LES]]**, generalmente caratterizzata da *artralgie* e *artrite*
	- si sviluppa in ca. 1/3 dei pazienti
	- in alcuni pazienti si riscontrano anche pleuriti, pericarditi o interessamento del [[Apparato respiratorio#Parenchima polmonare|parenchima polmonare]]
	- raramente viene indotto lupus renale
- In seguito a terapie prolungate si riscontrano, in quasi tutti i pazienti, **anomalie sierologiche**
	- es. aumento del titolo degli ANA
	- in assenza di sintomi, **non** rappresentano un'indicazione per sospendere la terapia
- Altri effetti collaterali comprendono
	- nausea e diarrea (ca. il 10% dei casi)
	- eruzioni cutanee
	- febbre
	- [[Epatiti#Da farmaci|epatite]] (in meno del 5%)
	- agranulocitosi (ca. 0,2%)
#### Farmacocinetica e posologia
##### Ciclo metabolico
1. Può essere somministrata con sicurezza per IV (si raccomanda prudenza) e IM; è ben assorbita quando somministrata *per os*
2. Un metabolita, la *N-acteilprocainamide* (*NAPA*[^12]) possiede attività della classe 3
	- un suo eccessivo accumulo è stato implicato nelle torsioni di punta, specialmente nei pazienti con insufficienza renale
	- alcuni soggetti acetilano rapidamente la procainamide → alti livelli di NAPA
		- in questi, la sindrome lupoide sembra essere meno frequente
3. Eliminazione per ==conversione epatica in NAPA== e per ==via renale==
	- t$_{1/2}$ = 3-4h → necessarie frequenti somministrazioni o l'impiego di formulazioni a lento rilascio
	- NAPA è eliminato per via renale → riduzione della dose in
		- pazienti con insufficienza renale
		- casi di ridotto [[Farmacocinetica e farmacodinamica#Volume di distribuzione|volume di distribuzione]] e diminuzione della [[Farmacocinetica e farmacodinamica#Clearance|clearance]] renale associati a [[Scompenso cardiaco|insufficienza cardiaca]]
###### NAPA
- t$_{1/2}$ notevolmente più lunga di quella della procainamide: ==si accumula più lentamente==
	- vanno tenuti sotto controllo i livelli plasmatici di entrambi, specialmente in pazienti con disfunzioni circolatorie o renali
##### Posologia
###### Ottenimento di un effetto rapido
- Procedimento:
	1. somministrazione IV di una dose di attacco (fino a 12 mg/kg) ad una velocità di 0,3 mg/kg/min o anche meno
	2. seguita da una seconda [[Farmacocinetica e farmacodinamica#Dose di mantenimento|dose di mantenimento]], somministrata a una velocità di 2-5 mg/min, con attento monitoraggio dei livelli plasmatici
- Il rischio di **effetti tossici gastroenterici** o **cardiaci** si ha per
	- concentrazioni plasmatiche > 8 $\mu$g/mL
	- concentrazioni di NAPA > 20 $\mu$g/mL
>[!warning]
>In pazienti in cui, occasionalmente, si accumulino alti livelli di NAPA, la procainamide può essere somministrata meno frequentemente. Ciò è possibile anche in caso di malattie renali (rallentata eliminazione).
###### Sotto controllo
- Si somministra una dose di 2-5 g al giorno
#### Uso terapeutico
>Non è più disponibile in Italia
- Efficacia nella maggior parte delle aritmie atriali e ventricolari
	- molti clinici, però, cercano di evitare terapie a lungo termine, data la necessità di somministrazioni frequenti e l'incidenza di effetti collegabili al lupus
- Utilizzata nella maggior parte delle unità coronariche come ==farmaco di seconda o terza scelta== per il trattamento delle aritmie ventricolari associate ad infarto acuto del miocardio
	- dopo ==lidocaina== e ==amiodarone==
### Chinidina (sottogruppo 1A)
![Chinidina.](https://i.imgur.com/pQg0iAK.png)
#### Effetti cardiaci
- Bloccando i canali del Na$^+$ produce
	- rallentamento dell'ascesa del potenziale d'azione e la conduzione
	- prolungamento della durata del QRS e dell'ECG
	- (prolunga anche la durata del potenziale d'azione mediante blocco di alcuni canali del K$^+$)
- Principali effetti tossici:
	- **eccessivo prolungamento dell'intervallo QT**
	- induzione di **torsioni di punta**
	- concentrazioni tossiche → blocco dei canali del sodio → rallentamento della conduzione
#### Effetti extracardiaci
- 1/3-1/2 dei pazienti vanno incontro a **disturbi gastrointestinali** (diarrea, nausea e vomito)
- Concentrazioni tossiche → sindrome caratterizzata da cefalea, vertigini e tinnito (**cinconismo**)[^14]
- Raramente si manifestano reazioni idiosincratiche: trombocitopenia, epatiti, edema angioneurotico e febbre
#### Farmacocinetica e impiego terapeutico
- Assorbita rapidamente dal tratto GI ed eliminata per metabolismo epatico
- Impiegata raramente per via dei suoi effetti tossici
##### Idrochinidina
>Diidrochinidina
- Impurezza commerciale della chinidina usata in Europa (Italia compresa) in sostituzione ad essa
- t$_{1/2}$ = 7-9h
- Si dà alla dose di 600-1200 mg al giorno (in rapporto al controllo dell'aritmia) frazionata in 4 prese quotidiane o 2-3 della preparazione ritardo
	- emoconcentrazioni efficaci = 1-3 $\mu$g/mL
### Disopiramide (sottogruppo 1A)
![Disopiramide.](https://i.imgur.com/4ZkTpUP.png)
#### Effetti cardiaci
- Effetti molto simili a quelli di procainamide e chinidina, ma presenta ==effetti antimuscarinici cardiaci più pronunciati==
	- nel corso del trattamento di flutter o fibrillazione atriale, vi si dovrebbe associare un farmaco che rallenti la conduzione AV
#### Tossicità
- Medesimi disturbi elettrofisiologici segnalati per la chinidina
- Azione inotropa negativa → **insufficienza cardiaca**
	- de novo o in pazienti con precedente depressione della funzione ventricolare sx
	- a causa di questo effetto, negli USA non viene utilizzata come farmaco di prima scelta
	- logicamente, ==impiego da escludere in pazienti affetti da insufficienza cardiaca==
- **Attività atropino-simile** responsabile degli effetti collaterali sintomatici:
	- ritenzione urinaria (soprattutto in pazienti con ipertrofia prostatica)
	- xerostomia
	- offuscamento della vista
	- peggioramento di [[glaucoma]] preesistente
	- stipsi
#### Farmacocinetica e posologia
>Negli USA è disponibile solo per uso orale (e noi seguiremo a capo chino lo zio Sam!)
- Dose impiegata generalmente *per os* = 150 mg tre volte al giorno
	- è stato usato fino a 1 g al giorno
	- in pazienti con insufficienza renale, la posologia va ridotta
#### Uso terapeutico
- Negli USA, il suo impiego è consentito solo per il trattamento delle aritmie ventricolari
### Lidocaina (sottogruppo 1B)
![Lidocaina.](https://i.imgur.com/k937HD2.png)
#### Effetti cardiaci
- ==Blocca con cinetica rapida i canali del sodio== (sia attivati che inattivati)
	1. blocco dello stadio inattivato = maggiori effetti sulle cellule con lunghi potenziali d'azione (es. cellule di Purkinje e cellule ventricolari) rispetto alle cellule atriali
	2. la rapida cinetica ai potenziali di riposo comporta una ripresa dal blocco nell'intervallo tra i potenziali d'azione e nessun effetto sulla conduzione
	3. l'aumentata inattivazione e la più lenta cinetica di sblocco dal legame comportano una *depressione selettiva della conduzione nelle cellule depolarizzate*
- ![Lidocaina, espletazione dei suoi effetti in tracciati raffiguranti il potenziale d'azione in una cellula muscolare (**superiore**) e la percentuale di canali bloccati (**inferiore**).](https://i.imgur.com/zdHCYeM.png)
#### Tossicità
- Tra i farmaci bloccanti i canali del Na$^+$, è quello col ==minor grado di tossicità a livello cardiaco==
	- sono rari gli effetti proaritmici
- Dosi elevate → depressione della contrattilità miocardica → **ipotensione**
	- soprattutto pazienti con scompenso cardiaco
- Più comuni effetti indesiderati:
	- come anche per gli altri anestetici locali, sono neurologici:
		- parestesie
		- tremore
		- nausea di origine centrale
		- stordimento
		- turbe di udito e linguaggio
		- convulsioni
	- questi effetti possono verificarsi
		- prevalentemente in pazienti anziani o vulnerabili
		- quando un bolo del farmaco viene somministrato troppo rapidamente
- Gli **effetti** dipendono dalla dose di farmaco somministrata
	- generalmente **di breve durata** e rispondono al [[Farmaci sedativo-ipnotici|diazepam]] IV
	- in genere, se si evitano livelli plasmatici > 9 $\mu$g/mL, è molto ben tollerata
#### Farmacocinetica e posologia
1. Poiché ha un ==elevato effetto di primo passaggio epatico== (solo il 3% della somministrazione *per os* si ritrova nel plasma), ==dev'essere somministrato per via parenterale==
2. t$_{1/2}$ = 1-2h
	- negli adulti, una dose di carico di 150-200 mg, somministrata in 15 min (come singola infusione o come serie di boli lenti), dovrebbe essere seguita da un'infusione di mantenimento di 2-4 mg/min per raggiungere livelli plasmatici terapeutici di 2-6 $\mu$g/mL
3. La determinazione dei livelli plasmatici è molto utile per ==aggiustare la velocità d'infusione==
	- alcuni pazienti possono richiedere (e tollerare) concentrazioni più alte, probabilmente per aumento dell'*$\alpha_1$-glicoproteina acida* nel plasma
		- proteina reattiva della fase acuta che lega la lidocaina, con conseguente diminuzione della frazione libera di farmaco che esercita l'azione farmacologica
	- pazienti con insufficienza cardiaca: possono essere ridotti sia volume di distribuzione che clearance totale
##### Variazioni del metabolismo
- La t$_{1/2}$ può aumentare meno di quanto sia prevedibile sulla base della sola variazione della [[Farmacocinetica e farmacodinamica#Clearance|clearance]]
	- pazienti con *malattie epatiche* → clearance ridotta e volume di distribuzione aumentato
		- la t$_{1/2}$ di eliminazione può essere aumentata di 3 volte o più
		- la dose di mantenimento dovrebbe essere diminuita, mentre può esser data l'abituale dose di carico
- La t$_{1/2}$ di eliminazione determina il tempo necessario per raggiungere lo stato stazionario (*steady state*)
	- in pazienti normali o con insufficienza cardiaca, le concentrazioni allo stato stazionario possono essere raggiunte in 8-10h
	- in pazienti con malattie epatiche possono essere necessarie 24-36h
- Con infusioni oltre le 24h, la *clearance* diminuisce e le concentrazioni ematiche aumentano
###### Interazioni farmacologiche
- I ==farmaci che riducono il flusso epatico== (es. ==propanololo==, ==cimetidina==) riducono la *clearance*, aumentando il **rischio di tossicità** (a meno che non se ne riduca la velocità d'infusione)
###### Affezioni renali
- Non hanno grandi effetti sulla disponibilità della lidocaina
#### Uso terapeutico
- ==Farmaco d'elezione== per ==soppressione della tachicardia e prevenzione della fibrillazione ventricolare== post cardioversione in un contesto di [[Cardiopatia ischemica (IHD)|ischemia acuta]]
	- tuttavia, il suo *uso profilattico di routine* ne può provocare un aumento della mortalità totale
- Molti medici la somministrano per IV solo a pazienti con aritmie
### Metilexina (sottogruppo 1B)
![Metilexina.](https://i.imgur.com/B1zMoaD.png)
- Congenere della lidocaina efficace *per os*
#### Effetti cardiaci ed extracardiaci
- Simile alla lidocaina
- A dosi terapeutiche, spesso causa **effetti indesiderati dose-dipendenti** (soprattutto neurologici), comprendenti tremori, offuscamento della vista e letargia
	- anche la nausea è un effetto frequente
- Ha dimostrato ==efficacia significativa contro il dolore cronico==
	- specie da neuropatia diabetica e lesioni nervose
	- dosaggio abituale = 450-750 mg al giorno *per os*
- Un'altra proprietà terapeutica è il ==controllo di segni e sintomi della miotonia non distrofica==
#### Usi clinici
- Impiegata nel trattamento delle aritmie ventricolari
#### Farmacocinetica
- t$_{1/2}$ = 8-20h → somministrazione 2-3 volte al giorno
	- dosi giornaliere di 600-1200 mg/die
### Flecainide (sottogruppo 1C)
![Flecainide.](https://i.imgur.com/6cCg5X7.png)
#### Effetti cardiaci
- Potente ==bloccante== dei canali del sodio e del potassio, con ==lenta cinetica di sblocco del legame==
	- (sebbene blocchi i canali, non prolunga il potenziale d'azione o l'intervallo QT)
- Non ha effetti antimuscarinici
- Estremamente efficace nel ==sopprimere le contrazioni ventricolari premature==
	- può causare, però, un serio aggravamento dell'aritmia quando somministrata, persino alle dosi normali, a pazienti con tachiaritmie ventricolari preesistenti o con pregresso infarto miocardico ed ectopie ventricolari
#### Usi clinici
- Attualmente impiegata in soggetti con cuore altrimenti normale che presentano aritmie sopraventricolari
#### Farmacocinetica
- Ben assorbita, ha una $t_{1/2}$ ≈ 20h
- Eliminazione → metabolismo epatico + via renale
- Dose abituale = 100-200 (anche 300) mg due volte al giorno
### Propafenone (sottogruppo 1C)
- Presenta analogie strutturali col ==propanololo== e possiede debole attività [[Farmaci antagonisti sui recettori adrenergici#Farmacologia di base degli antagonisti sui recettori $ beta$-adrenergici|β-bloccante]]
- Spettro d'azione molto simile a quello della chinidina, ma non prolunga il potenziale d'azione
#### Farmacocinetica
- Simile a quella della flecainide
- Metabolizzato dal fegato, con t$_{1/2}$ media di 5-7h
- La dose giornaliera abituale è di 450-900 mg divisi in tre dosi
	- (sono attualmente disponibili anche preparati ritardo)
#### Usi clinici
- Impiegato principalmente nelle aritmie sopraventricolari
#### Effetti indesiderati
- I più comuni sono **sapore metallico** e **stipsi**
- Si può anche verificare un'esacerbazione delle aritmie
### Moricizina (sottogruppo 1C)
>Ritirata dal mercato USA
- Antiaritmico derivato dalle fenotiazine usato per il trattamento delle aritmie ventricolari
- È un bloccante del canale del sodio relativamente potente
## Farmaci bloccanti i recettori $\beta$-adrenergici (classe 2)
#### Effetti cardiaci
- ==Propanololo== e farmaci similari ($\beta$-bloccanti)
	- non è ancora chiaro quanto l'azione $\beta$-bloccante o gli effetti diretti sulla membrana contribuiscano alla loro attività antiaritmica
	- efficacia ridotta rispetto ai bloccanti i canali del Na$^+$
	- ci sono sempre maggiori evidenze che possano ==prevenire infarto ricorrente e morte improvvisa==
- ==Esmololo==
	- $\beta$-bloccante con breve durata d'azione
	- impiegato principalmente come farmaco antiaritmico per aritmie intraoperatorie o per altre aritmie acute:
		1. 0,5 mg/kg come carico per infusione
		2. poi 0,05-0,2 mg/kg/min come mantenimento
- ==Sotalolo==
	- $\beta$-bloccante non selettivo che prolunga il potenziale d'azione (azione di classe 3)
## Farmaci che prolungano il periodo refrattario effettivo prolungando il potenziale d'azione (classe 3)
- Azione espletata mediante
	- blocco dei canali del K$^+$ a livello del muscolo cardiaco
	- aumento delle correnti d'ingresso (es. attraverso i canali del Na$^+$)
- Proprietà di =="uso-dipendenza" inversa== riguardo il prolungamento del potenziale d'azione:
	- meno marcato alle velocità di scarica elevate (ove desiderabile)
	- più marcato a basse velocità, alle quali può contribuire al rischio di **torsioni di punta**
>[!warning]
>Sebbene provochino **prolungamento significativo del tratto QT**, presentano una notevole diversità nel loro potenziale proaritmico per ciò che concerne la determinazione di torsioni di punta.
>- Studi recenti indicano che un tale eccessivo prolungamento può non essere il miglior indice predittivo di torsioni di punta farmaco-indotte.
>- Altri fattori di rischio importanti sono la stabilità del potenziale d'azione, lo sviluppo di una forma triangolare (triangolazione), la dipendenza inversa all'uso e la dispersione della ripolarizzazione.
### Amiodarone
![Amiodarone.](https://i.imgur.com/MEbUbme.png)
#### Effetti cardiaci
- Prolungamento del potenziale d'azione (e intervallo QT)
	- ==blocco delle correnti del potassio==: I$_{Kr}$ e I$_{Ks}$ (quest'ultima durante somministrazione cronica)
	- azione **non** uso-dipendente inversa
	- per rallentamento della frequenza cardiaca e della conduzione del nodo AV
- Malgrado la sua classificazione, blocca anche significativamente i canali del sodio inattivati e, debolmente, anche quelli del calcio
#### Effetti extracardiaci
- Causa ==vasodilatazione periferica== (soprattutto dopo somministrazione IV)
#### Tossicità
- Può determinare **bradicardia sintomatica** e **blocco cardiaco** in pazienti con preesistente malattia del seno o del nodo AV
- Oltre che nel cuore, si accumula in molti tessuti:
	- polmone → tossicità dose-dipendente e fibrosi
	- fegato → epatite da ipersensibilità
	- cute → fotodermatite e colorazione grigio-bluastra nelle aree fotoesposte
	- occhio → microdepositi corneali asintomatici e aloni nelle zone periferiche del campo visivo
		- (raramente una neurite ottica può esitare in cecità)
- **Blocca la conversione periferica** della *tiroxina* in *triiodotironina*
	- è anche una potenziale fonte di grandi quantità di iodio inorganico
	- può determinare ipo- o ipertiroidismo
>[!warning]
>La funzionalità tiroidea dovrebbe esser esaminata prima del trattamento e poi controllata periodicamente.
#### Farmacocinetica
##### Metabolismo
1. Assorbimento variabile, con biodisponibilità del 35-65%
2. Va incontro a ==metabolismo epatico==: il suo principale metabolita, il *desetilamiodarone*, è attivo
3. t$_{1/2}$ di eliminazione complessa:
	- componente rapida di 3-10 gg (50% del farmaco)
	- componente più lenta di diverse settimane
4. Post sospensione, gli effetti si mantengono per 1-3 mesi
	- concentrazioni misurabili nei tessuti possono esser riscontrate fino a un anno dopo l'interruzione
##### Posologia
- Dosaggio:
	- dose di attacco di 10g e dosi giornaliere di 0,8-1,2g
	- dose di mantenimento di 200-400 mg al giorno (anche 100mg)
- Gli effetti farmacologici sono ottenibili rapidamente con un ==carico IV== (5 mg/kg in 1h, poi 0,5.1 mg/min)
	- prolungamento dell'intervallo QT modesto
	- possono risultare significativi bradicardia e blocco AV
##### Interazioni farmacologiche
- Sono molte, essendo un substrato del *CYP3A4* → concentrazioni
	- aumentate da farmaci inibenti quest'enzima (es. ==cimetidina==[^14])
	- ridotte da farmaci inducenti quest'enzima (es. [[rifampicina]])
- Inibisce un certo numero di enzimi della famiglia del CYP450 e può determinare incrementi delle concentrazioni ematiche di molti farmaci (comprese [[Inibitori competitivi della HMG-CoA riduttasi (statine)|statine]], [[Warfarin ed anticoagulanti cumarinici|warfarin]] e ==digossina==)
	- la dose di warfarin dovrebbe essere ridotta di 1/3-1/2 e si dovrebbe procedere ad uno stretto monitoraggio del [[Patologia clinica - Ematologia#Tempo di protrombina|PT]]
#### Impiego terapeutico
- Basse dosi (100-200 mg al giorno) sono efficaci nel mantenimento del normale ritmo sinusale in pazienti con *fibrillazione atriale*
	- efficace anche nel prevenire la *tachicardia ventricolare ricorrente*
- Il suo ==impiego non== è ==associato ad aumento di mortalità== in pazienti con *coronaropatie* o *insufficienza cardiaca*
>[!info]
>In molti centri, il defibrillatore cardiaco impiantabile (==ICD==) ha sostituito la terapia farmacologica come modalità di trattamento primario per la **tachicardia ventricolare**, ma l'==amiodarone== può essere usato come ==terapia adiuvante==.
>- Ciò al fine di ridurre la frequenza delle scariche poco piacevoli dell'ICD.
>- Il farmaco aumenta la regolarità del battito e la soglia di defibrillazione e questi dispositivi devono essere ritardati dopo che è stata raggiunta una dose di mantenimento.
### Dronedarone
- Analogo strutturale dell'amiodarone in cui
	- gli atomi di *iodio* sono stati *eliminati* dall'anello fenilico
	- è stato aggiunto all'anello benzofuranico un *gruppo metansulfonilico*
- Progettato per eliminare gli effetti del farmaco progenitore sul metabolismo della tiroxina e modificarne anche l't$_{1/2}$
	- no alterazioni della funzionalità tiroidea o tossicità polmonare
	- è stata segnalata **tossicità epatica** (due casi gravi hanno richiesto il trapianto di fegato)
#### Meccanismo d'azione
- Agisce su molti canali, bloccando I$_{Kr}$, I$_{Ks}$, I$_{Ca}$, I$_{Na}$
- Blocca anche i recettori $\beta$-adrenergici
#### Farmacocinetica
- t$_{1/2}$ = 24h e può essere somministrato due volte al giorno alla dose fissa di 400 mg
- Assorbimento raddoppiato o triplicato quando viene assunto col cibo
- L'==eliminazione== è prevalentemente ==non renale==
	- inibisce la secrezione tubulare della [[Patologia clinica - Rene#Clearance della creatinina|creatinina]] → aumento dei livelli sierici intorno al 10-20%
	- non sono necessari aggiustamenti della posologia: la velocità di filtrazione non subisce alterazioni
- Sia substrato che inibitore del *CYP3A4*
#### Usi clinici
- Effetti cardiaci:
	- ripristina il ritmo sinusale solo in una piccola percentuale di pazienti (<15%) con fibrillazione atriale
	- riduce la frequenza ventricolare di 10-15 battiti/min rispetto al placebo
#### Effetti sfavorevoli
- Studi hanno dimostrato che
	- **raddoppia** gl'intervalli fra **episodi di fibrillazione atriale** ricorrente in pazienti con fibrillazione atriale parossistica o persistente
	- **aumenta** il rischio di **mortalità** nei pazienti con **insufficienza cardiaca**
>[!warning]
>Il farmaco porta un avviso importante ("*black box*") che ne proibisce l'uso nell'insufficienza cardiaca scompensata o in fase avanzata (fase IV).
### Vernakalant
- Bloccante di vari canali ionici sviluppato per il trattamento della fibrillazione atriale
	- ==prolunga== il ==periodo refrattario effettivo atriale==
		- mediante blocco dei canali I$_{Kur}$, I$_{Ach}$ e I$_{to}$
	- ==rallenta la conduzione a livello del nodo AV==
	- il periodo refrattario effettivo ventricolare non è modificato
- Alla dose massima impiegata nella clinica (1800 mg al giorno), non modifica l'intervallo QT dell'ECG
- Determina minore prolungamento dell'APD nei ventricoli e blocco uso-dipendente del canale $Na^+$
- Concentrazioni terapeutiche → **no** effetti sulla frequenza cardiaca
#### Tossicità
- **Disgeusia** (disturbo del gusto), starnuti, *parestesie*, tosse ed *ipotensione*
#### Farmacocinetica ed impiego terapeutico
- Post somministrazione IV, è metabolizzato nel fegato da *CYP2D6* e t$_{1/2}$ = 2h
	- tuttavia, con l'abituale schema terapeutico di 900 mg per os due volte al giorno, si osservano concentrazioni ematiche elevate per 12h
- Somministrato IV è efficace per la conversione di una fibrillazione atriale recente a normale ritmo sinusale nel 50% dei pazienti
	- approvazione ancora in sospeso
	- sono in corso sperimentazioni per il mantenimento del ritmo normale in pazienti con fibrillazione atriale parossistica o persistente
### Sotalolo
![Sotalolo.](https://i.imgur.com/sJ7oC66.png)
### Dofetilide
>Non disponibile in Italia
- Prolunga il potenziale d'azione (come i farmaci di classe 3) per ==blocco dose-dipendente== della ==componente rapida della I$_{Kr}$==
	- aumenta in condizioni di ipokaliemia
	- non blocca in maniera rilevante altri canali di K$^+$ o Na$^+$
- L'entità del blocco dimostra una ==scarsa dipendenza dalla frequenza di stimolazione==, tuttavia induce un minore prolungamento del potenziale d'azione a velocità di scarica elevate: **a frequenze elevate aumenta l'importanza di altri canali del potassio** (es. I$_{Ks}$)
#### Farmacocinetica
- Biodisponibile per il 100%
	- il ==verapamil==, aumentando il flusso ematico intestinale, ne aumenta la concentrazione plasmatica di picco
- L'80% della dose somministrata *per os* è eliminato immodificato dai reni
	- il rimanente si ritrova nell'urina come metaboliti inattivi
- Gli effetti di prolungamento del QT e i rischi di proaritmia ventricolare sono direttamente correlati alle concentrazioni plasmatiche: la ==dose== dev'essere ==calcolata in base al valore della [[Patologia clinica - Rene#Clearance della creatinina|clearance della creatinina]] misurato==
#### Usi clinici
- Il ==trattamento== dovrebbe essere ==iniziato== in ospedale ==dopo misure basali== dell'intervallo QT corretto per la frequenza (==QT$_c$==) e degli ==elettroliti== nel siero
	- controindicazioni all'utilizzo sono un QT$_c$ basale > 450 ms (500 ms in presenza di ritardo nella conduzione intraventricolare), bradicardia < 50 battiti/min ed ipokaliemia
- Approvata per il ==mantenimento del ritmo sinusale in pazienti con fibrillazione atriale==
### Ibutilide
- Come la dofetilide, rallenta la depolarizzazione cardiaca per blocco della I$_{Kr}$ e I$_{Na}$ lenta
- Somministrazione IV → rapida eliminazione epatica → metaboliti escreti per via renale
	- t$_{1/2}$ di eliminazione ≈ 6h
	- usata per la ==conversione acuta== del ==flutter== o della ==fibrillazione atriale a ritmo sinusale==
		- maggiore efficacia nel flutter
- **Effetto sfavorevole più importante** = eccessivo prolungamento dell'intervallo QT e torsioni di punta
	- i pazienti necessitano di un controllo ECG continuo per 4 h post infusione o fino a quando il $QT_C$ non sia tornato normale
## [[Farmaci bloccanti i canali del calcio (calcio-antagonisti)#Come antiaritmici|Farmaci che bloccano i canali del calcio (classe 4)]]
## Farmaci antiaritmici vari
- Non rientrano nelle classi 1-4 convenzionali (sono comunisti e anticonformisti... Dinkleberg....)
- Non sono menzionati, ma i seguenti farmaci possono ridurre le recidive di tachicardie e fibrillazione in pazienti con coronaropatie o insufficienza cardiaca congestizia:
	- [[Glicosidi digitalici|digitale]]
	- [[Inibitori dell'angiotensina|farmaci agenti sul sistema renina-angiotensina-aldosterone]]
	- olio di pesce
	- statine
### Adenosina
#### Meccanismo ed impiego clinico
- Nucleoside endogeno presente in tutto l'organismo con t$_{1/2}$ = 10s
##### Azione
- ==Attivazione una corrente rettificatrice di entrata del potassio== → marcata iperpolarizzazione
- ==Inibizione del flusso di calcio== → soppressione dei potenziali d'azione Ca$^{2+}$-dipendenti

>Essa è meno attiva in presenza di bloccanti dei recettori per l'adenosina (vedi [[Farmaci antiasmatici e per la BPCO#Metilxantine|metilxantine]]) e i suoi effetti sono potenziati da inibitori della captazione dell'adenosina (es. ==dipiridamolo==)
##### Somministrazione
- Quando data in bolo
	- inibisce direttamente la conduzione del nodo AV e aumenta il periodo refrattario dello stesso nodo
	- ha solo modesti effetti sul nodo SA
- Somministrata in bolo di 6 mg seguito, se necessario, da una dose di 12 mg
##### Utilizzi clinici
- Grazie alla sua ==elevata efficacia== (90-95%) e alla ==durata d'azione molto breve==, è attualmente il ==farmaco di prima scelta== per l'immediata conversione della *tachicardia sopraventricolare parossistica a ritmo sinusale*
- Una *rara variante della tachicardia ventricolare* è sensibile all'adenosina
#### Tossicità
- Causa
	- **vasodilatazione cutanea** in ca. il 20% dei pazienti
	- **dispnea** o **senso di costrizione toracica** (forse correlato a broncospasmo) in oltre il 10% dei trattati
- Può aversi un *blocco AV di grado elevato*, ma di durata molto breve
- Altri effetti indesiderati meno frequenti sono cefalea, ipotensione, nausea e parestesie
### Magnesio
- Adoperato in origine per pazienti con aritmie da digitale che presentavano [[ipomagnesemia]], il Mg$^{2+}$ per IV ha dimostrato effetti antiaritmici in alcuni pazienti con normali livelli sierici di questo ione
	- meccanismo espletato ignoto, ma è accertato che influenzi
		- Na$^+$/K$^+$-ATPasi
		- canali del sodio
		- alcuni canali del potassio
		- canali del calcio
#### Usi clinici
- La ==terapia== appare ==indicata== in pazienti con aritmie da digitale se è presente ipomagnesemia
- Indicata anche in alcuni pazienti con torsioni di punta (anche in presenza di valori di Mg$^{2+}$ nella norma)
#### Posologia
- Dose abituale = 1 g (come sale solfato) somministrata IV in 20 min
	- ripetuta una seconda volta, se necessario
### Potassio
- Gli effetti di un aumento di K$^+$ possono essere riassunti come
	1. azione depolarizzante sul potenziale di riposo
	2. azione stabilizzante sul potenziale di membrana (dovuta ad aumento della permeabilità al K$^+$)
- Alterazioni dei livelli ematici di potassio:
	- [[ipokaliemia]] → aumento del rischio di
		- post-depolarizzazioni precoci e ritardate
		- comparsa di *pacemaker* anomali, in special modo in presenza di digitale
	- [[iperkaliemia]] → depressione dei *pacemaker* ectopici[^15] + rallentamento della conduzione
- Poiché sia insufficienza che eccesso sono potenzialmente aritmogeni, la ==terapia== è volta alla ==normalizzazione dei gradienti e dei *pool* di potassio nell'organismo==
## Appendice: terapia non farmacologica delle aritmie cardiache
>Oltre 100 anni fa si osservò che, in semplici [[Modelli in vitro|modelli in vitro]] (es. anelli di tessuto di conduzione) il fenomeno del rientro veniva interrotto permanentemente sezionando il circuito di rientro
- Aritmie con circuiti definiti automaticamente
	- quali i rientri AV che utilizzano vie accessorie, rientro del nodo AV, flutter atriale e diverse forme di tachicardia ventricolare
	- oggi si trattano con
		- ==catetere di ablazione a radiofrequenza==
			- consente anche una mappatura dei circuiti di rientro
			- l'inserimento dei cateteri avviene mediante vene periferiche
			- fibrillazione atriale
				- può originare da una delle vene polmonari
				- entrambe le forme[^16] possono essere trattate isolando elettricamente le vene polmonari
					- mediante un catetere da ablazione a radiofrequenza
					- nel corso di concomitante intervento di cardiochirurgia
		- ==crioablazione==
- Altra forma di terapia è il ==defibrillatore impiantabile per cardioversione== (==ICD==)
	- strumento in grado di riconoscere e trattare automaticamente aritmie potenzialmente letali (es. fibrillazione ventricolare)
	- ampiamente utilizzati in pazienti rianimati dopo insorgenza di tali aritmie
		- riduzione della mortalità in pazienti
			- coronaropatici con frazione di eiezione <= 30%
			- con insufficienza cardiaca di classe II e III e nessuna precedente storia di aritmie
# Principi nell'impiego clinico dei farmaci antiaritmici
>Il margine tra efficacia e tossicità è particolarmente ristretto
### Valutazione prima del trattamento
#### 1. Eliminare la causa
- I fattori scatenanti comprendono
	- alterazioni dell'omeostasi interna (ipossia o alterazioni elettrolitiche, soprattutto [[ipomagnesemia]] o [[ipokaliemia]])
	- terapie farmacologiche
	- malattie come ipertiroidismo o insufficienza cardiaca
- È necessario separare queste condizioni di fondo anomale da fattori scatenanti come [[Patogenesi, prevenzione e trattamento dell'aterosclerosi|ischemia del miocardio]] o dilatazione cardiaca acuta, che possono essere reversibili e trattabili in modi diversi
#### 2. Stabilire una diagnosi certa
- Es. il ==verapamil== utilizzato in pazienti con tachicardia ventricolare erroneamente diagnosticata come tachicardia sopraventricolare può portare ad un'ipotensione catastrofica e ad arresto cardiaco
#### 3. Determinare le condizioni di base
- È fondamentale determinare se il cuore presenta anomalie strutturali
	- alcuni farmaci presentano un **rischio proaritmico** documentato in determinate malattie (es. ==farmaci di classe 1C== in pazienti con *ischemia cardiaca*)
- È importante stabilire una condizione di base affidabile rispetto alla quale si possa giudicare l'efficacia di un qualsiasi trattamento aritmico successivo; metodi per ottenere tale quantificazione:
	- monitoraggio ambulatoriale a lungo termine
	- studi elettrofisiologici che riproducono un'aritmia da trattare
	- riproduzione di un'aritmia bersaglio mediante esercizio sul tappeto mobile
	- impiego di monitoraggio transtelefonico per la registrazione di aritmie sporadiche, ma sintomatiche
#### 4. Necessità di terapia
- La mera identificazione di un'alterazione del ritmo cardiaco non comporta necessariamente un trattamento dell'aritmia
### Benefici e rischi
#### Benefici
- Si può guardare a due tipologie:
	- riduzione dei sintomi correlati all'aritmia
	- riduzione della mortalità a lungo termine in pazienti asintomatici
- Tra i farmaci discussi, solo i ==β-bloccanti== sono stati associati in maniera definitiva ad una riduzione della mortalità in pazienti relativamente asintomatici
#### Rischi
##### Dosaggio e abbinamento
- In alcuni casi, il rischio di reazioni avverse è chiaramente correlato a *dosi o concentrazioni plasmatiche elevate*
	- es. tremore indotto da ==lidocaina== o cinconismo da ==chinidina==
- In altri casi, le reazioni avverse non dipendono da concentrazioni plasmatiche elevate (es. agranulocitosi da ==procainamide==)
- Per molti effetti collaterali gravi sembra importante la *combinazione* tra terapia farmacologica e malattia cardiaca di base
##### Sindromi farmacologiche specifiche di induzione di aritmia
- Farmaci come [[Farmaci impiegati nelle aritmie cardiache#Chinidina (sottogruppo 1A)|chinidina]], [[Farmaci impiegati nelle aritmie cardiache#Sotalolo|sotalolo]], [[Farmaci impiegati nelle aritmie cardiache#Ibutilide|ibutilide]] e [[Farmaci impiegati nelle aritmie cardiache#Dofetilide|dofetilide]], che agiscono, almeno in parte, rallentando la ripolarizzazione e prolungando i potenziali d'azione cardiaci, possono provocare un **marcato prolungamento dell'intervallo QT** e **torsioni di punta**
	- trattamento basato su
		- riconoscimento dell'aritmia
		- sospensione di ogni farmaco dannoso
		- correzione dell'ipokaliemia
		- trattamento con procedure che aumentino la frequenza cardiaca
		- il Mg$^{2+}$ è efficace
- Farmaci che rallentano molto la conduzione (es. [[Farmaci impiegati nelle aritmie cardiache#Flecainide (sottogruppo 1C)|flecainide]] o alte dosi di chinidina) possono aumentare la frequenza di **aritmie da rientro**
	- particolarmente la ==tachicardia ventricolare== in pazienti con pregresso infarto miocardico
	- trattamento basato su
		- diagnosi
		- sospensione di farmaco dannoso
		- somministrazione di Na$^+$ IV
### Conduzione della terapia antiaritmica
- ==Urgenza== → via e velocità d'inizio della terapia
	- azione farmacologica immediata → somministrazione IV
	- si possono raggiungere concentrazioni terapeutiche somministrando più boli IV *lenti*
- La terapia farmacologica è considerabile efficace quando l'==aritmia== bersaglio viene ==soppressa senza comparsa di effetti tossici==
- ==Controllo delle concentrazioni plasmatiche== importante in
	- stabilire l'aderenza del paziente durante trattamenti a lungo termine
	- individuazione di interazioni farmacologiche che possono comportare
		- concentrazioni molto elevate a dosaggi bassi
		- concentrazioni molto basse per dosaggi elevati
## Appendice: uso dei farmaci antiaritmici: principi applicati alla fibrillazione atriale
>Vedi anche [[Aritmie#Fibrillazione atriale|fibrillazione atriale]]
### Patologia
- Più comune aritmia sostenuta osservata in clinica:
	- ~0,5% in individui di età inferiore ai 65 anni
	- 10% in pazienti oltre gli 80 anni
- L'ECG consente di identificare un precedente [[infarto miocardico]], ipertrofia ventricolare sx e una pre-eccitazione ventricolare
	- dovrebbero esser valutate la presenza e la gravità di una malattia cardiaca sottostante, utilizzando tecniche non invasive quali l'[[Diagnosi delle malattie cardiovascolari#Ecocardiografia|ecocardiografia]]
### Trattamento
- Inizia con l'obiettivo di **ridurre i sintomi del paziente** e **prevenire le complicanze del tromboembolismo e dell'insufficienza cardiaca indotta da tachicardia**
5. Controllo della f$_{\text{ventricolare}}$ (*rate control*) → impiego di un [[Farmaci bloccanti i canali del calcio (calcio-antagonisti)#Come antiaritmici|calcio-antagonista]]
	- da solo o in associazione con un $\beta$-bloccante
	- la ==digossina== può essere utile quando sia presente un'insufficienza cardiaca
6. Ripristino di un normale ritmo sinusale (*rhythm control*)
	- approcci differenti a seconda del Paese:
		- USA → ==cardioversione a corrente diretta==
		- alcuni Paesi → ==farmaco bloccante i canali del sodio==
	- pazienti con fibrillazione atriale parossistica:
		- opportuna singola dose *per os* di [[Farmaci impiegati nelle aritmie cardiache#Propafenone (sottogruppo 1C)|propafenone]] o [[Farmaci impiegati nelle aritmie cardiache#Flecainide (sottogruppo 1C)|flecainide]]
		- l'[[Farmaci impiegati nelle aritmie cardiache#Ibutilide|ilibutide]] IV può ripristinare prontamente il ritmo sinusale
	- condizioni di emergenza → ==cardioconversione==
7. Mantenimento di un normale ritmo sinusale: si usa un farmaco di classe 1 o 3
>[!info]
>Diversi studi dimostrano come, in termini di beneficio verso rischio, il ==controllo della frequenza== (mantenimento di 60 < f < 80 bpm) abbia un ==esito migliore del controllo del ritmo== (conversione al ritmo sinusale normale) per quanto riguarda le condizioni di salute a lungo termine di pazienti con fibrillazione atriale sostenuta.
# Sommario
![Farmaci antiaritmici, sommario 1.](https://i.imgur.com/N9iKsYp.png)
![Farmaci antiaritmici, sommario 2.](https://i.imgur.com/INOb5zh.jpeg)
![Farmaci antiaritmici, sommario 3.](https://i.imgur.com/w1bpRmp.png)
# Caso clinico
## Quesito
![Farmaci impiegati nelle aritmie cardiache: caso clinico - quesito.](https://i.imgur.com/33LhdCT.png)
## Risposta
![Farmaci impiegati nelle aritmie cardiache: caso clinico - risposta.](https://i.imgur.com/hDovSp4.png)






---
# Reference
[[Farmacologia]]
[[Aritmie]]



[^1]: Ciò ha portato ad una rivalutazione dei relativi rischi e benefici.
[^2]: Stimolatori cardiaci: sembra opportuno ricordare che la parola *pacemaker* ha significato di marcatempo, segnapassi per strutture anatomiche e stimolatore cardiaco per gli aspetti clinici.
[^3]: Soprattutto Na$^+$, K$^+$, Ca$^{2+}$ e Cl$^-$.
[^4]: Vale a dire che i canali selettivi per quello ione sono aperti.
[^5]: Il potenziale di membrana in corrispondenza del quale non verrebbe generata alcuna corrente ionica, anche se i canali fossero aperti.
[^6]: Vale a dire quelli presenti nelle cellule miocardiche.
[^7]: (a volte considerate insieme come "I$_K$")
[^8]: Determinate da alterazioni nel recupero dei canali dallo stato inattivo o da una durata del potenziale d'azione anomala.
[^9]: Cellule che mostrano fase 4 di depolarizzazione lenta perfino in condizioni normali (es. alcune fibre di Purkinje)
[^10]: APD = Potenziale d'azione
[^11]: Azione della classe 3.
[^12]: ![NAPA](https://i.imgur.com/0etu25K.png)
[^13]: **Cinconismo**: forma di comportamento o atteggiamento caratterizzato da una certa dose di cinismo, ovvero una visione scettica e disillusa della vita e delle motivazioni umane.
[^14]: [[antagonisti ai recettori H2]]
[^15]: Per sopprimere il nodo SA è necessaria una grave iperpotassiemia.
[^16]: parossistica e persistente